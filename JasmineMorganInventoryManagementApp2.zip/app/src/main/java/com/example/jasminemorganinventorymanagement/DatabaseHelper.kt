package com.example.jasminemorganinventorymanagement

import android.content.ClipData
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    // companion object holds constants for the database, tables, and columns
    companion object {
        private const val DATABASE_NAME = "inventory.db"
        private const val DATABASE_VERSION = 1

        // User Table constants
        private const val TABLE_USERS = "users"
        private const val COLUMN_USER_ID = "id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"

        // Inventory Table constants
        private const val TABLE_INVENTORY = "inventory"
        private const val COLUMN_ITEM_ID = "id"
        private const val COLUMN_ITEM_NAME = "name"
        private const val COLUMN_ITEM_QUANTITY = "quantity"
    }

    // Called when the database is created for the first time
    override fun onCreate(db: SQLiteDatabase?) {
        // SQL statement to create the users table
        val createUserTable = "CREATE TABLE $TABLE_USERS (" +
                "$COLUMN_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_USERNAME TEXT," +
                "$COLUMN_PASSWORD TEXT)"
        db?.execSQL(createUserTable)

        // SQL statement to create the inventory table
        val createInventoryTable = "CREATE TABLE $TABLE_INVENTORY (" +
                "$COLUMN_ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_ITEM_NAME TEXT," +
                "$COLUMN_ITEM_QUANTITY INTEGER)"
        db?.execSQL(createInventoryTable)
    }

    // Called when the database needs to be upgraded
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        // Drop older tables if they exist and recreate them
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_INVENTORY")
        onCreate(db)
    }

    // --- User Functions ---

    /**
     * Adds a new user to the database.
     * Returns the ID of the new user, or -1 if an error occurred.
     */
    fun addUser(username: String, password: String): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_USERNAME, username)
        values.put(COLUMN_PASSWORD, password) // Note: In a real app, hash the password!
        val id = db.insert(TABLE_USERS, null, values)
        db.close()
        return id
    }

    /**
     * Checks if a user exists with the given username and password.
     * Returns true if the user exists, false otherwise.
     */
    fun checkUser(username: String, password: String): Boolean {
        val db = this.readableDatabase
        val columns = arrayOf(COLUMN_USER_ID)
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)
        val cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)
        val count = cursor.count
        cursor.close()
        db.close()
        return count > 0
    }

    // --- Inventory Functions ---

    /**
     * Adds a new item to the inventory table.
     */
    fun addItem(name: String, quantity: Int) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_ITEM_NAME, name)
        values.put(COLUMN_ITEM_QUANTITY, quantity)
        db.insert(TABLE_INVENTORY, null, values)
        db.close()
    }

    /**
     * Retrieves all items from the inventory table.
     * Returns a list of Item objects.
     */
    fun getAllItems(): List<ClipData.Item> {
        val itemList = mutableListOf<Item>()
        val db = this.readableDatabase
        // The "cursor" holds all the rows returned by the query
        val cursor = db.rawQuery("SELECT * FROM $TABLE_INVENTORY", null)

        // Loop through all rows and add them to the list
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ITEM_NAME))
                val quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_QUANTITY))
                // Create an Item object and add it to our list
                itemList.add(Item(id, name, quantity))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return itemList
    }

    /**
     * Deletes an item from the database by its ID.
     */
    fun deleteItem(itemId: Int) {
        val db = this.writableDatabase
        db.delete(TABLE_INVENTORY, "$COLUMN_ITEM_ID = ?", arrayOf(itemId.toString()))
        db.close()
    }

    /**
     * Finds an item's ID by its name.
     * Returns the item ID, or -1 if not found.
     */
    fun getItemIdByName(name: String): Int {
        val db = this.readableDatabase
        var itemId = -1
        val cursor = db.query(TABLE_INVENTORY, arrayOf(COLUMN_ITEM_ID), "$COLUMN_ITEM_NAME = ?", arrayOf(name), null, null, null)
        if (cursor.moveToFirst()) {
            itemId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ITEM_ID))
        }
        cursor.close()
        db.close()
        return itemId
    }

    /**
     * Updates the quantity of a specific item.
     * Returns the number of rows affected.
     */
    fun updateItemQuantity(itemId: Int, newQuantity: Int): Int {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_ITEM_QUANTITY, newQuantity)
        val rowsAffected = db.update(TABLE_INVENTORY, values, "$COLUMN_ITEM_ID = ?", arrayOf(itemId.toString()))
        db.close()
        return rowsAffected
    }
}
