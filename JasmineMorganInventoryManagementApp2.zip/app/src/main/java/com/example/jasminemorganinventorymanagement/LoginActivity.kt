package com.example.jasminemorganinventorymanagement

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    // Declare UI elements and a reference to our database helper
    private lateinit var usernameEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var loginButton: Button
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize the DatabaseHelper
        dbHelper = DatabaseHelper(this)

        // Find the views from the XML layout by their ID
        usernameEditText = findViewById(R.id.usernameEditText)
        passwordEditText = findViewById(R.id.passwordEditText)
        loginButton = findViewById(R.id.loginButton)

        // Set a listener to handle the button click
        loginButton.setOnClickListener {
            handleLogin()
        }
    }

    private fun handleLogin() {
        // Get the text input from the user and trim whitespace
        val username = usernameEditText.text.toString().trim()
        val password = passwordEditText.text.toString().trim()

        // Check for empty fields first
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username and password cannot be empty.", Toast.LENGTH_SHORT).show()
            return
        }

        // --- CORE LOGIN/REGISTRATION LOGIC ---

        // Check if the user exists in the database
        if (dbHelper.checkUser(username, password)) {
            // If user exists and password is correct, log them in
            Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
            navigateToDataDisplay()
        } else {
            // If user does not exist, create a new account for them
            // For this project, we create it automatically as per directions.
            val userId = dbHelper.addUser(username, password)
            if (userId != -1L) {
                // If user was added successfully
                Toast.makeText(this, "New account created. Logging in.", Toast.LENGTH_SHORT).show()
                navigateToDataDisplay()
            } else {
                // If there was an error creating the user
                Toast.makeText(this, "Error creating account. Please try again.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun navigateToDataDisplay() {
        // Create an Intent to start the DataDisplayActivity
        val intent = Intent(this, DataDisplayActivity::class.java)
        startActivity(intent)
        // Finish this activity so the user cannot go back to the login screen
        finish()
    }
}
