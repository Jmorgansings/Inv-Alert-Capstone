package com.example.jasminemorganinventorymanagement

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.ui.semantics.text
import com.google.android.material.floatingactionbutton.FloatingActionButton

class DataDisplayActivity : AppCompatActivity() {

    // Declare UI elements and a reference to our database helper
    private lateinit var inventoryGridView: GridView
    private lateinit var addItemButton: FloatingActionButton
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var inventoryAdapter: ArrayAdapter<String>
    private val inventoryList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_display)

        // Initialize the DatabaseHelper
        dbHelper = DatabaseHelper(this)

        // Find views from the XML layout
        inventoryGridView = findViewById(R.id.inventoryGridView)
        addItemButton = findViewById(R.id.addItemButton)

        // Setup the adapter for the GridView
        inventoryAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, inventoryList)
        inventoryGridView.adapter = inventoryAdapter

        // Load initial data from the database
        loadInventoryData()

        // Set listener for the "Add Item" button
        addItemButton.setOnClickListener {
            showAddItemDialog()
        }

        // Set listeners for updating and deleting items
        setupGridViewListeners()
    }

    private fun loadInventoryData() {
        // This function reads all items from the database and updates the GridView
        val items = dbHelper.getAllItems() // You will create this function in DatabaseHelper
        inventoryList.clear()
        items.forEach { item ->
            // For simplicity, we'll display name and quantity. You can format this as you like.
            inventoryList.add("${item.name}\nQuantity: ${item.quantity}")
        }
        inventoryAdapter.notifyDataSetChanged()
    }

    private fun showAddItemDialog() {
        // This function shows a pop-up dialog to add a new item
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add New Item")

        // Inflate a custom layout for the dialog
        val dialogLayout = layoutInflater.inflate(R.layout.dialog_add_item, null)
        val itemNameEditText = dialogLayout.findViewById<EditText>(R.id.itemNameEditText)
        val itemQuantityEditText = dialogLayout.findViewById<EditText>(R.id.itemQuantityEditText)
        builder.setView(dialogLayout)

        builder.setPositiveButton("Add") { dialog, _ ->
            val name = itemNameEditText.text.toString().trim()
            val quantityStr = itemQuantityEditText.text.toString().trim()

            if (name.isNotEmpty() && quantityStr.isNotEmpty()) {
                val quantity = quantityStr.toInt()
                dbHelper.addItem(name, quantity) // You will create this function in DatabaseHelper
                loadInventoryData() // Refresh the grid
                Toast.makeText(this, "Item added successfully.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Name and quantity cannot be empty.", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.cancel()
        }
        builder.show()
    }

    private fun setupGridViewListeners() {
        // Set a long click listener to delete items
        inventoryGridView.setOnItemLongClickListener { parent, view, position, id ->
            val selectedItemString = inventoryList[position]
            val itemName = selectedItemString.split("\n")[0] // Extract name from the string

            // Show a confirmation dialog before deleting
            AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete '$itemName'?")
                .setPositiveButton("Delete") { _, _ ->
                    val itemId = dbHelper.getItemIdByName(itemName) // You will need a function for this
                    if (itemId != -1) {
                        dbHelper.deleteItem(itemId) // You will create this function
                        loadInventoryData() // Refresh the grid
                        Toast.makeText(this, "'$itemName' deleted.", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()

            return@setOnItemLongClickListener true
        }

        // Set a short click listener to update items
        inventoryGridView.setOnItemClickListener { parent, view, position, id ->
            // For Project Three, we'll implement update logic here.
            // You would typically show a dialog similar to showAddItemDialog()
            // to allow the user to enter a new quantity.
            Toast.makeText(this, "Update functionality to be added.", Toast.LENGTH_SHORT).show()
        }
    }
}

    